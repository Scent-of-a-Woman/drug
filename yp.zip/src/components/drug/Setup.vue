 
<template> 
	
</template> 

<script> 
export default { 

  name: 'Setup', 


  data () { 
    return { 

    }; 
  }, 

  methods: { 

  } 


}; 
</script> 

<style  scoped> 

</style> 