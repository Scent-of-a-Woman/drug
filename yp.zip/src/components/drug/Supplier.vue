 
<template> 
</template> 

<script> 
export default { 

  name: 'Supplier', 


  data () { 
    return { 

    }; 
  }, 

  methods: { 

  } 


}; 
</script> 

<style  scoped> 

</style> 