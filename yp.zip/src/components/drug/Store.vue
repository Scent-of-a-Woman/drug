 
<template> 
	<div>adasdadsa</div>
</template> 

<script> 
export default { 

  name: 'Store', 


  data () { 
    return { 

    }; 
  }, 

  methods: { 

  } 


}; 
</script> 

<style scoped> 

</style> 