 
<template> 
</template> 

<script> 
export default { 

  name: 'Druglist', 


  data () { 
    return { 

    }; 
  }, 

  methods: { 

  } 


}; 
</script> 

<style  scoped> 

</style> 