<template>
  <div id="app">
      <router-view></router-view>
  </div>
</template>

<script>
export default {
   data () {
    return {
     
    }
  }
}
</script>

<style>
body,html{
  height: 100%;
  margin:0;
  padding: 0;
}
#app{
  height: 100%;
}
</style>


